import 'package:chat_web/views/webpage/conversation_screen.dart';
import 'package:flutter/material.dart';

class TabChat extends StatefulWidget {
  @override
  _TabChatState createState() => _TabChatState();
}

class _TabChatState extends State<TabChat> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
