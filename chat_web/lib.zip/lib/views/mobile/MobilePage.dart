import 'package:flutter/material.dart';
//import 'package:responsive_builder/responsive_builder.dart';

class MobilePage extends StatefulWidget {
  @override
  _MobilePageState createState() => _MobilePageState();
}

class _MobilePageState extends State<MobilePage> {
  @override
  Widget build(BuildContext context) {
    return Text('data');
  }
}
