import 'package:flutter/material.dart';

class MobileChat extends StatefulWidget {
  @override
  _MobileChatState createState() => _MobileChatState();
}

class _MobileChatState extends State<MobileChat> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blue,
      ),
    );
  }
}
