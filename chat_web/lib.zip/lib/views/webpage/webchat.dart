import 'package:chat_web/views/webpage/chatroom.dart';
import 'package:chat_web/views/webpage/conversation_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
//import 'package:get/get.dart';
import 'package:responsive_builder/responsive_builder.dart';

class WebChat extends StatelessWidget {
  final SizingInformation constraint;
  WebChat({Key key, @required this.constraint}) : super(key: key);

  QuerySnapshot snapshot;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(color: Colors.white, boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 4, spreadRadius: 4)
        ]),
        alignment: Alignment.center,
        width: constraint.screenSize.width,
        height: constraint.screenSize.height,
        child: Row(
          children: [
            Container(
                width: constraint.screenSize.width,
                alignment: Alignment.center,
                child: ChatRoom(
                    constraint:
                        constraint)), // these are the screens ?//yes sir I will show one sec//when I click on the user name  it should show the conversation screen on the right side instead its expanding to whole screen// it will not work this way becaose you have dependency // it may work this way but it's not recommended ..// you want it to be like when you click the name the based on that user chat should show right ?yes sir //this will take time to develop and only chatroom will take care of this let's develop it after 30 minutes // let me finish some importatnt task ok sir
            /*   Expanded(
              child: Container(
                width: constraint.screenSize.width * 0.7,
                alignment: Alignment.center,
                child: ConversationScreen(
                  constraint: constraint,
                ),
              ),
            ) */
          ],
        ),
      ),
    );
  }
}


// Backup




/* import 'package:chat_web/views/webpage/chatroom.dart';
import 'package:chat_web/views/webpage/conversation_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
//import 'package:get/get.dart';
import 'package:responsive_builder/responsive_builder.dart';

class WebChat extends StatelessWidget {
  final SizingInformation constraint;
  WebChat({Key key, @required this.constraint}) : super(key: key);

  QuerySnapshot snapshot;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(color: Colors.white, boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 4, spreadRadius: 4)
        ]),
        alignment: Alignment.center,
        width: constraint.screenSize.width,
        height: constraint.screenSize.height,
        child: Row(
          children: [
            Container(
                width: constraint.screenSize.width * 0.25,
                alignment: Alignment.center,
                child: ChatRoom(constraint: constraint)),  
            Expanded(
              child: Container(
                width: constraint.screenSize.width * 0.7,
                alignment: Alignment.center,
                child: ConversationScreen(
                  constraint: constraint,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
 */