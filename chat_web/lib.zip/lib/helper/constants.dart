class Constants {
  static String myName = '';
  static String myEmail = '';
}
