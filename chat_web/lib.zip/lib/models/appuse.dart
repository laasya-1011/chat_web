class AppUse {
  String userId;
  AppUse({this.userId});
}
